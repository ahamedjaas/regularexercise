package com.example.trial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day7Application {

	public static void main(String[] args) {
		SpringApplication.run(Day7Application.class, args);
	}

}
