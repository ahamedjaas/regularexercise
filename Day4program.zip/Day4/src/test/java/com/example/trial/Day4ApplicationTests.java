package com.example.trial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
