package com.example.trial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4Application {

	public static void main(String[] args) {
		SpringApplication.run(Day4Application.class, args);
	}

}
